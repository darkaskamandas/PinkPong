Tutorial for making a clone of the classic Pong game, using Unity. Check out the tutorial on Awesome Inc U: [Unity Pong tutorial](https://www.awesomeincu.com/tutorials/unity-pong/)
